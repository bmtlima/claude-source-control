import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

/**
 * Represents a single agent's source control panel and its state.
 */
class AgentSourceControl {
  public readonly scm: vscode.SourceControl;
  public readonly changesGroup: vscode.SourceControlResourceGroup;
  public readonly conflictsGroup: vscode.SourceControlResourceGroup;
  private disposables: vscode.Disposable[] = [];
  private watcher: vscode.FileSystemWatcher | undefined;

  constructor(
    public readonly agentId: string,
    public readonly agentLabel: string,
    public readonly agentDir: string,
    private readonly workspaceRoot: string,
    private readonly conflictTracker: ConflictTracker
  ) {
    this.scm = vscode.scm.createSourceControl(
      `multiClaude.${agentId}`,
      `🤖 ${agentLabel}`
    );
    this.scm.inputBox.visible = false;

    this.changesGroup = this.scm.createResourceGroup('changes', 'Changes');
    this.changesGroup.hideWhenEmpty = true;

    this.conflictsGroup = this.scm.createResourceGroup('conflicts', '⚠ Conflicts');
    this.conflictsGroup.hideWhenEmpty = true;

    this.startWatching();
    this.refresh();
  }

  /**
   * Watch the agent's directory for file changes and refresh when they occur.
   */
  private startWatching(): void {
    const pattern = new vscode.RelativePattern(this.agentDir, '**/*');
    this.watcher = vscode.workspace.createFileSystemWatcher(pattern);

    this.watcher.onDidChange(() => this.refresh());
    this.watcher.onDidCreate(() => this.refresh());
    this.watcher.onDidDelete(() => this.refresh());

    this.disposables.push(this.watcher);
  }

  /**
   * Scan the agent directory, diff against workspace, and update the SCM panel.
   */
  async refresh(): Promise<void> {
    const changedFiles = await this.findChangedFiles(this.agentDir, '');
    const modifiedByThisAgent = new Set(changedFiles.map(f => f.relativePath));

    // Report our files to the conflict tracker
    this.conflictTracker.report(this.agentId, modifiedByThisAgent);
    const conflictingFiles = this.conflictTracker.getConflictsFor(this.agentId);

    const changes: vscode.SourceControlResourceState[] = [];
    const conflicts: vscode.SourceControlResourceState[] = [];

    for (const file of changedFiles) {
      const originalUri = vscode.Uri.file(path.join(this.workspaceRoot, file.relativePath));
      const agentUri = vscode.Uri.file(path.join(this.agentDir, file.relativePath));

      const resourceState: vscode.SourceControlResourceState = {
        resourceUri: agentUri,
        command: {
          command: 'vscode.diff',
          arguments: [
            file.isNew ? vscode.Uri.parse('untitled:empty') : originalUri,
            agentUri,
            `${path.basename(file.relativePath)} (${this.agentLabel})`
          ],
          title: 'Show changes'
        },
        decorations: {
          strikeThrough: file.isDeleted,
          tooltip: file.isNew
            ? `New file by ${this.agentLabel}`
            : `Modified by ${this.agentLabel}`,
          iconPath: file.isNew
            ? new vscode.ThemeIcon('diff-added')
            : new vscode.ThemeIcon('diff-modified')
        }
      };

      if (conflictingFiles.has(file.relativePath)) {
        conflicts.push(resourceState);
      } else {
        changes.push(resourceState);
      }
    }

    this.changesGroup.resourceStates = changes;
    this.conflictsGroup.resourceStates = conflicts;
    this.scm.count = changedFiles.length;
  }

  /**
   * Recursively find files in the agent dir that differ from the workspace.
   */
  private async findChangedFiles(
    dir: string,
    relativeTo: string
  ): Promise<Array<{ relativePath: string; isNew: boolean; isDeleted: boolean }>> {
    const results: Array<{ relativePath: string; isNew: boolean; isDeleted: boolean }> = [];

    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return results;
    }

    for (const entry of entries) {
      const relPath = relativeTo ? `${relativeTo}/${entry.name}` : entry.name;

      // Skip common non-essential directories
      if (entry.isDirectory()) {
        if (['node_modules', '.git', '.claude-agents'].includes(entry.name)) {
          continue;
        }
        const subResults = await this.findChangedFiles(
          path.join(dir, entry.name),
          relPath
        );
        results.push(...subResults);
        continue;
      }

      if (!entry.isFile()) continue;

      const workspaceFile = path.join(this.workspaceRoot, relPath);
      const agentFile = path.join(dir, entry.name);

      if (!fs.existsSync(workspaceFile)) {
        // File exists in agent dir but not workspace = new file
        results.push({ relativePath: relPath, isNew: true, isDeleted: false });
        continue;
      }

      // Compare contents
      try {
        const original = fs.readFileSync(workspaceFile);
        const modified = fs.readFileSync(agentFile);
        if (!original.equals(modified)) {
          results.push({ relativePath: relPath, isNew: false, isDeleted: false });
        }
      } catch {
        // If we can't read, assume changed
        results.push({ relativePath: relPath, isNew: false, isDeleted: false });
      }
    }

    return results;
  }

  /**
   * Accept a single file: copy from agent dir to workspace.
   */
  acceptFile(agentFileUri: vscode.Uri): void {
    const relativePath = path.relative(this.agentDir, agentFileUri.fsPath);
    const targetPath = path.join(this.workspaceRoot, relativePath);

    // Ensure target directory exists
    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
    fs.copyFileSync(agentFileUri.fsPath, targetPath);

    this.refresh();
    vscode.window.showInformationMessage(
      `Accepted ${relativePath} from ${this.agentLabel}`
    );
  }

  /**
   * Discard a single file: delete the agent's copy so it no longer shows as changed.
   */
  discardFile(agentFileUri: vscode.Uri): void {
    const relativePath = path.relative(this.agentDir, agentFileUri.fsPath);
    const workspaceFile = path.join(this.workspaceRoot, relativePath);

    if (fs.existsSync(workspaceFile)) {
      // Reset to workspace version
      fs.copyFileSync(workspaceFile, agentFileUri.fsPath);
    } else {
      // New file — just delete it
      fs.unlinkSync(agentFileUri.fsPath);
    }

    this.refresh();
  }

  /**
   * Accept all changes from this agent.
   */
  acceptAll(): void {
    const allFiles = [
      ...this.changesGroup.resourceStates,
      ...this.conflictsGroup.resourceStates
    ];
    for (const resource of allFiles) {
      this.acceptFile(resource.resourceUri);
    }
  }

  /**
   * Discard all changes from this agent.
   */
  discardAll(): void {
    const allFiles = [
      ...this.changesGroup.resourceStates,
      ...this.conflictsGroup.resourceStates
    ];
    for (const resource of allFiles) {
      this.discardFile(resource.resourceUri);
    }
  }

  dispose(): void {
    this.conflictTracker.remove(this.agentId);
    this.scm.dispose();
    this.disposables.forEach(d => d.dispose());
  }
}

/**
 * Tracks which files are modified by which agents to detect conflicts.
 */
class ConflictTracker {
  private fileToAgents: Map<string, Set<string>> = new Map();
  private agentToFiles: Map<string, Set<string>> = new Map();
  private onConflictChangeCallbacks: Array<() => void> = [];

  /**
   * An agent reports the set of files it has modified.
   */
  report(agentId: string, files: Set<string>): void {
    // Clear old data for this agent
    const oldFiles = this.agentToFiles.get(agentId) || new Set();
    for (const f of oldFiles) {
      this.fileToAgents.get(f)?.delete(agentId);
    }

    // Set new data
    this.agentToFiles.set(agentId, files);
    for (const f of files) {
      if (!this.fileToAgents.has(f)) {
        this.fileToAgents.set(f, new Set());
      }
      this.fileToAgents.get(f)!.add(agentId);
    }

    this.notifyChange();
  }

  remove(agentId: string): void {
    const files = this.agentToFiles.get(agentId) || new Set();
    for (const f of files) {
      this.fileToAgents.get(f)?.delete(agentId);
    }
    this.agentToFiles.delete(agentId);
    this.notifyChange();
  }

  /**
   * Get the set of files that conflict for a given agent
   * (i.e., also modified by at least one other agent).
   */
  getConflictsFor(agentId: string): Set<string> {
    const result = new Set<string>();
    const files = this.agentToFiles.get(agentId) || new Set();
    for (const f of files) {
      const agents = this.fileToAgents.get(f);
      if (agents && agents.size > 1) {
        result.add(f);
      }
    }
    return result;
  }

  onChange(callback: () => void): void {
    this.onConflictChangeCallbacks.push(callback);
  }

  private notifyChange(): void {
    this.onConflictChangeCallbacks.forEach(cb => cb());
  }
}

/**
 * Main extension manager. Discovers agents and creates SCM panels.
 */
class MultiClaudeManager {
  private agents: Map<string, AgentSourceControl> = new Map();
  private conflictTracker = new ConflictTracker();
  private disposables: vscode.Disposable[] = [];
  private statusBarItem: vscode.StatusBarItem;

  constructor(private readonly workspaceRoot: string) {
    this.statusBarItem = vscode.window.createStatusBarItem(
      vscode.StatusBarAlignment.Left,
      100
    );
    this.statusBarItem.show();
    this.updateStatusBar();

    // Watch for new agent directories being created/removed
    const agentsDir = path.join(workspaceRoot, '.claude-agents');
    const dirWatcher = vscode.workspace.createFileSystemWatcher(
      new vscode.RelativePattern(agentsDir, '*')
    );
    dirWatcher.onDidCreate(() => this.discoverAgents());
    dirWatcher.onDidDelete(() => this.discoverAgents());
    this.disposables.push(dirWatcher);

    // Update status bar when conflicts change
    this.conflictTracker.onChange(() => this.updateStatusBar());

    this.registerCommands();
    this.discoverAgents();
  }

  private registerCommands(): void {
    this.disposables.push(
      vscode.commands.registerCommand('multiClaude.createAgent', () => this.createAgent()),
      vscode.commands.registerCommand('multiClaude.removeAgent', () => this.removeAgent()),
      vscode.commands.registerCommand('multiClaude.acceptFile', (resourceState: vscode.SourceControlResourceState) => {
        const agent = this.findAgentForUri(resourceState.resourceUri);
        agent?.acceptFile(resourceState.resourceUri);
      }),
      vscode.commands.registerCommand('multiClaude.discardFile', (resourceState: vscode.SourceControlResourceState) => {
        const agent = this.findAgentForUri(resourceState.resourceUri);
        agent?.discardFile(resourceState.resourceUri);
      }),
      vscode.commands.registerCommand('multiClaude.acceptAll', (scmProvider: vscode.SourceControl) => {
        const agent = this.findAgentForScm(scmProvider);
        agent?.acceptAll();
      }),
      vscode.commands.registerCommand('multiClaude.discardAll', (scmProvider: vscode.SourceControl) => {
        const agent = this.findAgentForScm(scmProvider);
        agent?.discardAll();
      })
    );
  }

  /**
   * Scan .claude-agents/ directory and create/remove SCM panels accordingly.
   */
  private discoverAgents(): void {
    const agentsDir = path.join(this.workspaceRoot, '.claude-agents');

    if (!fs.existsSync(agentsDir)) {
      return;
    }

    const entries = fs.readdirSync(agentsDir, { withFileTypes: true });
    const currentAgentIds = new Set<string>();

    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      if (entry.name.startsWith('.')) continue;

      const agentId = entry.name;
      currentAgentIds.add(agentId);

      if (!this.agents.has(agentId)) {
        const agentDir = path.join(agentsDir, agentId);
        const label = this.formatAgentLabel(agentId);
        const agent = new AgentSourceControl(
          agentId,
          label,
          agentDir,
          this.workspaceRoot,
          this.conflictTracker
        );
        this.agents.set(agentId, agent);
      }
    }

    // Remove agents whose directories no longer exist
    for (const [id, agent] of this.agents) {
      if (!currentAgentIds.has(id)) {
        agent.dispose();
        this.agents.delete(id);
      }
    }

    this.updateStatusBar();
  }

  /**
   * Create a new agent via the command palette.
   */
  private async createAgent(): Promise<void> {
    const name = await vscode.window.showInputBox({
      prompt: 'Agent name (e.g., "auth-middleware", "settings-page")',
      placeHolder: 'agent-name',
      validateInput: (value) => {
        if (!value) return 'Name is required';
        if (!/^[a-zA-Z0-9_-]+$/.test(value)) return 'Use only letters, numbers, hyphens, underscores';
        if (this.agents.has(value)) return 'Agent already exists';
        return null;
      }
    });

    if (!name) return;

    const agentsDir = path.join(this.workspaceRoot, '.claude-agents');
    const agentDir = path.join(agentsDir, name);

    fs.mkdirSync(agentDir, { recursive: true });

    // Copy workspace files to agent directory (excluding heavy dirs)
    await this.copyWorkspaceToAgent(this.workspaceRoot, agentDir);

    vscode.window.showInformationMessage(
      `Agent "${name}" created. Its working copy is at .claude-agents/${name}/`
    );

    this.discoverAgents();
  }

  /**
   * Remove an agent via the command palette.
   */
  private async removeAgent(): Promise<void> {
    const agentIds = Array.from(this.agents.keys());
    if (agentIds.length === 0) {
      vscode.window.showInformationMessage('No agents to remove.');
      return;
    }

    const selected = await vscode.window.showQuickPick(agentIds, {
      placeHolder: 'Select agent to remove'
    });

    if (!selected) return;

    const agent = this.agents.get(selected);
    if (agent) {
      agent.dispose();
      this.agents.delete(selected);

      const agentDir = path.join(this.workspaceRoot, '.claude-agents', selected);
      fs.rmSync(agentDir, { recursive: true, force: true });

      vscode.window.showInformationMessage(`Agent "${selected}" removed.`);
      this.updateStatusBar();
    }
  }

  /**
   * Copy workspace files to an agent directory, excluding heavy/irrelevant dirs.
   */
  private async copyWorkspaceToAgent(src: string, dest: string): Promise<void> {
    const EXCLUDE = new Set([
      'node_modules', '.git', '.claude-agents', 'dist', 'out',
      '.vscode-test', '__pycache__', '.next', 'build', '.DS_Store'
    ]);

    const entries = fs.readdirSync(src, { withFileTypes: true });
    for (const entry of entries) {
      if (EXCLUDE.has(entry.name)) continue;

      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);

      if (entry.isDirectory()) {
        fs.mkdirSync(destPath, { recursive: true });
        await this.copyWorkspaceToAgent(srcPath, destPath);
      } else if (entry.isFile()) {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  }

  private findAgentForUri(uri: vscode.Uri): AgentSourceControl | undefined {
    for (const agent of this.agents.values()) {
      if (uri.fsPath.startsWith(agent.agentDir)) {
        return agent;
      }
    }
    return undefined;
  }

  private findAgentForScm(scmProvider: vscode.SourceControl): AgentSourceControl | undefined {
    for (const agent of this.agents.values()) {
      if (agent.scm === scmProvider) {
        return agent;
      }
    }
    return undefined;
  }

  private formatAgentLabel(id: string): string {
    return id.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  }

  private updateStatusBar(): void {
    const count = this.agents.size;
    if (count === 0) {
      this.statusBarItem.text = '';
      this.statusBarItem.hide();
      return;
    }

    let totalConflicts = 0;
    const seenConflicts = new Set<string>();
    for (const agent of this.agents.values()) {
      const conflicts = this.conflictTracker.getConflictsFor(agent.agentId);
      for (const f of conflicts) {
        seenConflicts.add(f);
      }
    }
    totalConflicts = seenConflicts.size;

    const conflictText = totalConflicts > 0 ? ` $(warning) ${totalConflicts} conflict(s)` : '';
    this.statusBarItem.text = `$(hubot) ${count} agent(s)${conflictText}`;
    this.statusBarItem.show();
  }

  dispose(): void {
    for (const agent of this.agents.values()) {
      agent.dispose();
    }
    this.agents.clear();
    this.statusBarItem.dispose();
    this.disposables.forEach(d => d.dispose());
  }
}

let manager: MultiClaudeManager | undefined;

export function activate(context: vscode.ExtensionContext): void {
  const workspaceFolders = vscode.workspace.workspaceFolders;
  if (!workspaceFolders || workspaceFolders.length === 0) {
    return;
  }

  const workspaceRoot = workspaceFolders[0].uri.fsPath;
  manager = new MultiClaudeManager(workspaceRoot);
  context.subscriptions.push({ dispose: () => manager?.dispose() });
}

export function deactivate(): void {
  manager?.dispose();
}
